package ncsa.d2k.modules.projects.pgroves.vis.falsecolor;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

/**
	contains the sliders that set the max and min of the color range. 
	responsible for updating the other components when they change
*/
public class SliderControlPanel extends JPanel 
	implements ChangeListener{

	/** swing object controlling the minimum */
	JSlider minSlider;
	/** swing object controlling the maximum*/
	JSlider maxSlider;	

	/** who we belong to, who we tell our new values to */
	FalseColorPanel parent;
		
	public SliderControlPanel(FalseColorPanel fcp){
		
		parent = fcp;
				
		minSlider = new JSlider(SwingConstants.VERTICAL, 0, 100, 1);
		minSlider.setValue(0);
		minSlider.setPaintLabels(false);
		maxSlider = new JSlider(SwingConstants.VERTICAL, 0, 100, 1);
		maxSlider.setValue(100);
		maxSlider.setPaintLabels(false);
		maxSlider.addChangeListener(this);
		minSlider.addChangeListener(this);

		this.setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		this.add(minSlider);
		this.add(maxSlider);
	}
		
	public void stateChanged(ChangeEvent e) {
		
		JSlider source = (JSlider)e.getSource();
		
		if (!source.getValueIsAdjusting()) {
			
			if( source == minSlider){
				parent.setSliderMin(minSlider.getValue());
			}else if (source == maxSlider){
				parent.setSliderMax(maxSlider.getValue());
			}else{
				System.out.println("SliderControls stateChanged error");
			}
			
		}
	}
	
}//Slidercontrols

