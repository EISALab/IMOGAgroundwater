package ncsa.d2k.modules.projects.pgroves.vis.falsecolor;

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.event.*;

import ncsa.d2k.modules.projects.pgroves.bp.*;
import ncsa.d2k.modules.core.datatype.table.Table;

/**
	Applies a false, or pseudo, coloring to a grayscale image. 

	@author pgroves
	@date 01/21/04
	*/

public class FalseColorPanel extends JPanel /*implements ActionListener*/{
	
	private boolean debug = true;

	FalseColorMap colorMap;
	ColorBarWidget colorBar;
	SliderControlPanel controls;
	//ImagePanel iPan;
	Table originalImage;
	double[] range;

	int bandIndex = 0;

	/**all the stuff that isn't the image(s) being viewed*/
	JPanel controlPanel;

	/** holds the color bar and sliders */
	JPanel colorControlPanel;
	
	/** selection between types of color map */
	//JComboBox colorMapChooser;

	ColorImagePanel imagePanel;	
	/**
		Does the main work of creating the entire false color vis
		panel from an ImageObject. This is the method that
		should be used directly
		
	*/	

	public FalseColorPanel(Table img){

		originalImage = img;

		this.setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		
		controlPanel = new JPanel();
		controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));
		controlPanel.add(Box.createVerticalStrut(10));

		colorControlPanel = new JPanel();
		colorControlPanel.setLayout(
			new BoxLayout(colorControlPanel, BoxLayout.X_AXIS));
		
		range = this.getRange(img);
		colorMap = new LinearColorMap(range[0], range[1]);
		//colorMap = new LogColorMap(range[0], range[1], 2);
		
		colorBar = new ColorBarWidget(range[0], range[1], colorMap);
		colorControlPanel.add(colorBar);

		controls = new SliderControlPanel(this);
		colorControlPanel.add(controls);

		controlPanel.add(colorControlPanel);
		controlPanel.add(Box.createVerticalStrut(10));
		this.add(controlPanel);

		/*try{
		ImageObject fcImg=this.createFalseColorImg(img, bandIndex, colorMap);
		iPan = (ImagePanel)SimpleImagePanel.getImagePanel(fcImg);
		
		iPan.SetImageObject(fcImg);
		this.add(iPan);
		}catch(Exception e){
			e.printStackTrace();
		}*/
		imagePanel = new ColorImagePanel(img, colorMap);
		this.add(imagePanel);
	}

	/**
		a constructor for when you also want to mark locations 
		(such as wells).

		@param img the table that represents the image
		@param markPixels a table with pixel locations to mark in the
			image.
		@param circlePixelSet an array of indices into markPixels that
		indicate which pixels should be represented by circles. Any
		others will be represented by crosses.
	*/
	public FalseColorPanel(Table img, Table markPixels, 
		int[]	circlePixelSet){
		
		this(img);
		//this is dumb - a regular colorimagepanel is made, only
		//to be destroyed before it's displayed (in the other
		//constructor - needs to be cleaned up
		this.remove(imagePanel);
		imagePanel = new ColorImageWithWellsPanel(img, colorMap,
			markPixels, circlePixelSet);
		this.add(imagePanel);
	}


	/** this method assumes it will receive an int between 0 and 100
	representing the percentage of the way up the slider has been set */
	public void setSliderMin(int smn){
		double adjustedMin = range[0];
		adjustedMin +=  (range[1] - range[0]) * ((double)smn / 100.0d);
			
		System.out.println("Slider Min:"+smn+" adjusted:"+adjustedMin);
		colorMap.setMinIntensity(adjustedMin);
		colorBar.setSliderMin(adjustedMin);
		refresh();
	}
	/** this method assumes it will receive an int between 0 and 100
	representing the percentage of the way up the slider has been set */
	public void setSliderMax(int smx){
		double adjustedMax = range[0];
		adjustedMax +=  (range[1] - range[0]) * ((double)smx / 100.0d);
		
		System.out.println("Slider Max:"+smx+" adjusted:"+adjustedMax);
		colorMap.setMaxIntensity(adjustedMax);
		colorBar.setSliderMax(adjustedMax);
		refresh();
	}

	/**
		repaints the false color images after settings have been changed
	*/
	private void refresh(){
		/*try{
		iPan.BuildImagePanel(
			createFalseColorImg(originalImage, bandIndex, colorMap));
		}catch(Exception e){
		}*/
		imagePanel.updateColoring(colorMap);
		this.repaint();
	}
		



	

	
	/**
		finds the min and max of the intensity values of a grayscale
		image. Will return the range as <code>double</code>'s,
		regardless of the primitive type of the image.

		@param img the Image/Table to scan

		@return a double array where [0] is the min and [1] is the max
	*/

	public double[] getRange(Table img){
		
		double[] range = new double[2];
		int min = 0;
		int max = 1;
		range[min]=Double.MAX_VALUE;
		range[max]=Double.MIN_VALUE;

		double val;
		int i, j;
		int numCols = img.getNumColumns();
		int numRows = img.getNumRows();
		
		for(i = 0; i < numCols; i++){
			for(j = 0; j < numRows; j++){
				 
				val = img.getDouble(j, i);
				if(val<range[min]){
					range[min]=val;
				}
				if(val>range[max]){
					range[max]=val;
				}
			}
		}
		if(debug){
			System.out.println(" Min:"+range[min]+" Max:"+range[max]);
		}
		return range;
	}


}//FalseColor
		
