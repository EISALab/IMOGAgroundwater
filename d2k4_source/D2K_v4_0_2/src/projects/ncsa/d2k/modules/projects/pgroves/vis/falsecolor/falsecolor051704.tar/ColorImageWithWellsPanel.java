package ncsa.d2k.modules.projects.pgroves.vis.falsecolor;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.awt.color.*;
import javax.swing.*;
import ncsa.d2k.modules.core.datatype.table.Table;

/**
	adds circle and tick marks of well locations to the image panel

	@author Peter Groves
	@date 02/19/04
	*/

public class ColorImageWithWellsPanel extends ColorImagePanel{
	
	/** holds the pixel locations of the wells to draw on top
		of the image */
	Table wells;
	
	/**indicates which of the wells will be circles (indices into
	the wells table)*/	
	int[] circleWells;

	/**for speed purposes, cache the locations of the cross mark
	wells (exactly every well location that isn't a circleWell*/
	int[] crossWells;

	
	/** containes the awt circle objects to draw. cached for speed*/
	Ellipse2D[] wellCircleObjects;
	
	/** containes the awt line objects to draw to make crosses. cached
	for speed. note: there are two lines for every well*/
	Line2D[] wellCrossObjects;	
	
	
	/**
		same as superclass, but also requires a table containing the
		well locations (in pixel coordinate system, not geographic
		coordinate system). the circleWellLocations is an array of
		indices that indicate which wells will be circles. all other
		wells will be crosses. 

		@param img a grayscale image represented in a Table were the
			column represents the x pixel coordinate and the row the y
			pixel coordinate.
		@param colorFunction a color map with info on which color a
			given intensity value should be shown as	
		@param wellLocations a Table with a column of x pixel locations
			and one of y pixel locations
		@param circleWellLocations indices into wellLocations about
			which wells should be shown as circles (the rest will be
			crosses). must be in ascending order		
	*/
	public ColorImageWithWellsPanel(Table img, FalseColorMap colorFunction,
		Table wellLocations, int[] circleWellLocations){

		super(img, colorFunction);

		wells = wellLocations;
		circleWells = circleWellLocations;

		int numWells = wells.getNumRows();
		int numCircles = circleWells.length;
		int numCrosses = numWells - numCircles;
		crossWells = new int[numCrosses];

		int i, j, k;
		j = 0;
		k = 0;
		for(i = 0; i < numWells; i++){
			if(!(j >= numCircles) &&
				(circleWells[j] == i)){
				j++;
			}else{
				crossWells[k] = i;
				k++;
			}
		}

		//lets make the graphics geometry objects
		wellCircleObjects = new Ellipse2D[numCircles];
		wellCrossObjects = new Line2D[numCrosses * 2];
		
		//hold dimensions
		double x, y;
		//make every mark the same size
		double markWidth = 10;
		for(i = 0; i < numCircles; i++){
			x = wellLocations.getDouble(circleWells[i], 0);
			y = wellLocations.getDouble(circleWells[i], 1);
			//System.out.println("Circle Location "+i+": "+x+", "+y);

			wellCircleObjects[i] = new Ellipse2D.Double(
				x - .5 * markWidth,
				y - .5 * markWidth,
				markWidth,
				markWidth);
		}
		for(i = 0; i < numCrosses; i++){
			x = wellLocations.getDouble(crossWells[i], 0);
			y = wellLocations.getDouble(crossWells[i], 1);
			//System.out.println("Cross Location "+i+": "+x+", "+y);
			
			wellCrossObjects[i] = new Line2D.Double(
				x - .5 * markWidth, y,
				x + .5 * markWidth, y);
			
			wellCrossObjects[i + numCrosses] = new Line2D.Double(
				x, y - .5 * markWidth,
				x, y + .5 * markWidth);
		}

		updateColoring(colorFunction);
			
	}
/*
	public void updateColoring(FalseColorMap colorFunction){
		super.updateColoring(colorFunction);

		if(wellCircleObjects != null){
			Graphics2D g2d= colorImage.createGraphics();
			g2d.setPaint(Color.BLACK);
			g2d.setStroke(new BasicStroke(3.0f));
			g2d.setComposite(AlphaComposite.SrcOver);
			//the circles and crosses
			int numMarks = wellCircleObjects.length;
			int i;
			for(i = 0; i < numMarks; i++){
				g2d.draw(wellCircleObjects[i]);
				System.out.println(wellCircleObjects[i]);
			}

			numMarks = wellCrossObjects.length;
			for(i = 0; i < numMarks; i++){
				g2d.draw(wellCrossObjects[i]);
			}
			g2d.dispose();
		}
	}
	*/

	/**
		overridden from the superclass so that it also draws the wells.
		*/
		
	protected void paintComponent(Graphics g){
		//super.paintComponent(g);
		//System.out.println("In paint");
		
		Graphics2D g2d = (Graphics2D)g.create();
		g2d.drawImage(colorImage, 0, 0, this);
		g2d.setStroke(new BasicStroke(3.0f));
		g2d.setPaint(Color.BLACK);
		//g2d.setComposite(AlphaComposite.SrcOver);
		//the circles and crosses
		int numMarks = wellCircleObjects.length;
		int i;
		for(i = 0; i < numMarks; i++){
			g2d.draw(wellCircleObjects[i]);
			//System.out.println(wellCircleObjects[i]);
		}

		numMarks = wellCrossObjects.length;
		for(i = 0; i < numMarks; i++){
			g2d.draw(wellCrossObjects[i]);
		}
		g2d.dispose();
	}
		

	}
	

		
		
